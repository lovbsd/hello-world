package bit.com.a.service;

import java.util.List;

import bit.com.a.dto.BbsDto;

public interface BbsService {

	List<BbsDto> getBbsList();
	
	boolean writeBbs(BbsDto dto);
	
	BbsDto getBbs(int seq);
	void readCount(int seq);
}
