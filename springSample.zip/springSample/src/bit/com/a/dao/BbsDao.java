package bit.com.a.dao;

import java.util.List;

import bit.com.a.dto.BbsDto;

public interface BbsDao {

	List<BbsDto> getBbsList();	
	
	boolean writeBbs(BbsDto dto);
	
	BbsDto getBbs(int seq);
	void readCount(int seq);
}
